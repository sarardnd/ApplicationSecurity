use askama::Template;
use axum::{
    extract::Form,
    http::StatusCode,
    response::{Html, IntoResponse, Response},
    routing::{get, post, Router},
};
use serde::Deserialize;
use std::fmt;
use std::fs;
use std::io;
use tokio::net::TcpListener;

fn hash_with_salt(s: &str) -> String {
    let salt_path = "./src/salt.txt";
    let salt = fs::read_to_string(salt_path).expect("Should be able to read salt file");
    assert_eq!(
        sha256::digest(&salt),
        "f83c8dbbf9f0d2ecb84fdaf3c9a6e80948fc576a44a7c61c116f7231c1e606cd"
    ); // checks salt file includes correct text
    let password_and_salt = s.to_string() + &salt;
    sha256::digest(password_and_salt.to_string())
}

#[derive(Debug, Clone)]
pub struct PasswordError;
impl fmt::Display for PasswordError {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        write!(f, "Password too weak.")
    }
}

pub struct Password {
    hash: String,
}
impl Password {
    pub fn set(password: &str) -> Result<Self, PasswordError> {
        // should only accept strong passwords
        if password.len() > 8
            && password.chars().any(|c| c.is_uppercase())
            && password.chars().any(|c| c.is_lowercase())
            && password.chars().any(|c| c.is_digit(10))
            && !password.chars().all(char::is_alphanumeric)
        {
            Ok(Password {
                hash: hash_with_salt(password),
            })
        } else {
            Err(PasswordError)
        }
    }

    pub fn get_hash(self) -> String {
        self.hash
    }
}

#[derive(Template, Default)]
#[template(path = "login.html")]
struct LoginTemplate<'a> {
    // mirrors login.html's state
    username: &'a str,
    password: &'a str,
    error_message: &'a str,
}

#[derive(Template)]
#[template(path = "home.html")]
struct HomeTemplate<'a> {
    // mirrors home.html's state
    username: &'a str,
}

/// renders html page or returns an error
fn render_template(template: impl Template) -> Response {
    // template = html page
    match template.render() {
        Ok(rendered) => Html(rendered).into_response(),
        Err(e) => {
            eprint!("Failed to render template: {e:?}");
            StatusCode::INTERNAL_SERVER_ERROR.into_response()
        }
    }
}

/// renders login page with blank boxes
/// first thing user is greeted by
async fn welcome() -> Response {
    let template = LoginTemplate::default(); //template initialised with empty strings
    render_template(template)
}

#[derive(Deserialize)]
struct User {
    username: String,
    password: String,
}

/// handles login logic
/// will (when implemented) check against db
async fn login(fields: Form<User>) -> Response {
    let password_checked = Password::set(&fields.password); // this is currently more like a registration, not a login
    if !fields.username.is_empty() && password_checked.is_ok() {
        println!(
            "Log in success! \nUser:{}\nPassword:{}",
            &fields.username,
            &fields.password // remove the plaintext password being logged
        ); // change this to a log with timestamp
        let template: HomeTemplate<'_> = HomeTemplate {
            username: &fields.username,
        };
        return render_template(template);
    } else {
        println!(
            "Log in failed! \nUser:{}\nPassword:{}",
            &fields.username,
            &fields.password // remove the plaintext password being logged
        ); // change this to a log with timestamp
        let template = LoginTemplate {
            username: &fields.username,
            password: "",
            error_message: "Invalid credentials!",
        };
        return render_template(template);
    }
}

#[tokio::main]
async fn main() -> io::Result<()> {
    let router = Router::new() // this handles url extensions, currently just using "/" because its easier
        .route("/", get(welcome))
        .route("/", post(login)); // how to handle multiple buttons with different functions?

    let listener = TcpListener::bind("127.0.1:8080").await?;
    println!("Listening on http://{}", listener.local_addr()?);

    axum::serve(listener, router).await
}
